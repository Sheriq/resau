
package hi.rpc.ws;

import javax.jws.WebService;
//Service Implementation
@WebService(endpointInterface = "hi.rpc.ws.Calcule")
public class CalculeImpl implements Calcule{
	int[] piece = { 50, 20, 10, 5, 2, 1};
	@Override
	public String Calcule(int some) {
		//int s = Integer.parseInt(some);
                String result="some = "+some+"\n";
            int[] reslt = new int[piece.length];
            for (int i = 0; i < piece.length; i++) {
                if (some >= piece[i]) {
                    reslt[i] = some / piece[i];
                    some = some % piece[i];
                }
            }
            for (int i = 0; i < reslt.length; i++) {
                if (reslt[i] != 0) {
                    result+=(" " + reslt[i] + " de piece " + piece[i] + "\n");
                }
            }
            return result;
	}
}